package consoleapp.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class Company implements Serializable {
    private Integer id;
    private String name;
    private List<Integer> customers;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Integer> customers) {
        this.customers = customers;
    }
}
