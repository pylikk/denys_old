package consoleapp.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class Customer implements Serializable {
    private Integer id;
    private String name;
    private List<Integer> projects;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getProjects() {
        return projects;
    }

    public void setProjects(List<Integer> projects) {
        this.projects = projects;
    }
}
