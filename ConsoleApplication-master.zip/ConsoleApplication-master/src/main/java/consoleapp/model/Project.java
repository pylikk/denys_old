package consoleapp.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class Project implements Serializable {
    private Integer id;
    private String name;
    private List<Integer> teams;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getTeams() {
        return teams;
    }

    public void setTeams(List<Integer> teams) {
        this.teams = teams;
    }
}
