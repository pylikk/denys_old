package consoleapp.application;

import consoleapp.view.ConsoleHelper;

public class ConsoleApplication {
    public static void main(String[] args) {
        ConsoleHelper helper = new ConsoleHelper();
        helper.start();
    }
}
