package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class CompanyController extends AbstractController {
    public CompanyController(AbstractDAO dao) {
        super(dao);
    }

}
