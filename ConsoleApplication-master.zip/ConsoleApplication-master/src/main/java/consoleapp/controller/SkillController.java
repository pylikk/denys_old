package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class SkillController extends AbstractController{

    public SkillController(AbstractDAO dao) {
        super(dao);
    }

}
