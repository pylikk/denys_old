package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public abstract class AbstractController {

    public AbstractController(AbstractDAO dao) {
        this.dao = dao;
    }

    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    AbstractDAO dao;

    public void add(Object object) {
        dao.add(object);
    }
    public void update(Object object) {
        dao.update(object);
    }
    public void delete(String id) {
        dao.delete(id);
    }

    public String readConsole(){
        String command = null;
        try {
            command = reader.readLine();
            if (command.equalsIgnoreCase("EXIT")){
                reader.close();
                System.exit(0);
            }
            else if (command.equalsIgnoreCase("MENU")) {
                return null;
            }
            else
                return command;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return command;
    }

    public List<Object> all () {
        return dao.getAll();
    }

    public Object getObject(int id){
        return dao.getObject(id);
    }

}
