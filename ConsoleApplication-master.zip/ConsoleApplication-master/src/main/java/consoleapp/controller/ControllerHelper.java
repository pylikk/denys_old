package consoleapp.controller;

import consoleapp.dao.DAOHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ControllerHelper {

    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static ControllerHelper controllerHelper;

    private ControllerHelper () {}
    public static ControllerHelper getControllerHelper () {
        if (controllerHelper == null)
            controllerHelper = new ControllerHelper();
        return controllerHelper;
    }

    public String readConsole(){
        String command = null;
        try {
            command = reader.readLine();
            if (command.equalsIgnoreCase("EXIT")){
                reader.close();
                System.exit(0);
            }
            else if (command.equalsIgnoreCase("MENU")) {
                return null;
            }
            else
                return command;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return command;
    }


}
