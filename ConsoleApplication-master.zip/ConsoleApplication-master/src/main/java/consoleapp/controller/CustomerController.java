package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class CustomerController extends AbstractController {
    public CustomerController(AbstractDAO dao) {
        super(dao);
    }

}
