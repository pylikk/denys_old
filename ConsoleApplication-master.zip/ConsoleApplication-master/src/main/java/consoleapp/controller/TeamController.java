package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class TeamController extends AbstractController {
    public TeamController(AbstractDAO dao) {
        super(dao);
    }

}
