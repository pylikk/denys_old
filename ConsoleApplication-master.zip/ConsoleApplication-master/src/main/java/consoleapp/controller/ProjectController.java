package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class ProjectController extends AbstractController {

    public ProjectController(AbstractDAO dao) {
        super(dao);
    }

}
