package consoleapp.controller;

import consoleapp.dao.AbstractDAO;

public class DeveloperController extends AbstractController{
    public DeveloperController(AbstractDAO dao) {
        super(dao);
    }

}
