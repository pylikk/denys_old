package consoleapp.dao;

import consoleapp.model.Company;

public class CompanyDAO extends AbstractDAO{

    @Override
    public void add(Object object) {
        ((Company) object).setId(getMaxId() + 1);
        write(object);
    }

    @Override
    public String getName() {
        return "Company";
    }

    @Override
    public String getId(Object object) {
        return ((Company) object).getId().toString();
    }
}
