package consoleapp.dao;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DAOHelper {

    static {
        String[] folders = new String[] {
          "Company",
          "Customer",
          "Developer",
          "Project",
          "Team",
          "Skill"
        };
        for (String folder : folders) {
            try {
                Files.createDirectories(Paths.get("src/main/resources/" + folder));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
