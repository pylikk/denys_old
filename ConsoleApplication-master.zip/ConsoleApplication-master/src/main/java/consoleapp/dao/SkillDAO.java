package consoleapp.dao;

import consoleapp.model.Skill;

public class SkillDAO extends AbstractDAO{

    @Override
    public void add(Object object) {
        ((Skill) object).setId(getMaxId() + 1);
        write(object);
    }

    @Override
    public String getName() {
        return "Skill";
    }

    @Override
    public String getId(Object object) {
        return ((Skill) object).getId().toString();
    }

}
