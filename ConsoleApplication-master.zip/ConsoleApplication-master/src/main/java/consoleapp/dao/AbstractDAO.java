package consoleapp.dao;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractDAO {

    private final String resources = "src/main/resources/";

    public abstract void add(Object object);

    public abstract String getName();

    public abstract String getId(Object object);

    public String[] getEntityNames(String path, String format) {
        String[] entities = Paths.get(path).toFile().list();
        if (entities != null) {
            for (int i = 0; i < entities.length; i++) {
                entities[i] = entities[i].substring(0, entities[i].indexOf(format));
            }
            return entities;
        }
        return null;
    }

    public void update (Object object) {
        write(object);
    }

    public String[] getAllId() {
        return getEntityNames(resources + getName(), ".txt");
    }

    public List<Object> getAll() {
        List<Object> list = new ArrayList<>();
        String[] allId = getAllId();
        if (allId != null) {
            for (String id : allId) {
                list.add(getObject(Integer.parseInt(id)));
            }
        }
        return list;
    }

    public int getMaxId() {
        int max = 0;
        String[] allId = getAllId();
        if (allId != null) {
            for (String id : allId) {
                try {
                    int i = Integer.parseInt(id);
                    if (i > max)
                        max = i;
                } catch (Exception e) {
                }
            }
        }
        return max;
    }

    public void delete(String id) {
        File file = new File(resources + getName() + "/" + id + ".txt");
        file.delete();
    }


    public void write(Object object) {
        File file = new File(resources + getName() + "/" + getId(object) + ".txt");
        try {
            file.createNewFile();
            ObjectOutputStream objectOS = new ObjectOutputStream(new FileOutputStream(file));
            objectOS.writeObject(object);
            objectOS.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object getObject(int id) {
        Object object = null;
        File file = new File(resources + getName() + "/" + id + ".txt");
        try {
            ObjectInputStream objectIS = new ObjectInputStream(new FileInputStream(file));
            object = objectIS.readObject();
            objectIS.close();
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return object;
    }

}
