package consoleapp.dao;

import consoleapp.model.Project;

public class ProjectDAO extends AbstractDAO {

    @Override
    public void add(Object object) {
        ((Project) object).setId(getMaxId() + 1);
        write(object);
    }

    @Override
    public String getName() {
        return "Project";
    }

    @Override
    public String getId(Object object) {
        return ((Project) object).getId().toString();
    }
}
