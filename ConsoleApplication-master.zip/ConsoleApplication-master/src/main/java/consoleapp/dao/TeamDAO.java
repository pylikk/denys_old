package consoleapp.dao;

import consoleapp.model.Team;

public class TeamDAO extends AbstractDAO {

    @Override
    public void add(Object object) {
        ((Team) object).setId(getMaxId() + 1);
        write(object);
    }

    @Override
    public String getName() {
        return "Team";
    }

    @Override
    public String getId(Object object) {
        return ((Team) object).getId().toString();
    }
}
