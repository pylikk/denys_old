package consoleapp.dao;

import consoleapp.model.Customer;

public class CustomerDAO extends AbstractDAO {

    @Override
    public void add(Object object) {
        ((Customer) object).setId(getMaxId() + 1);
        write(object);
    }

    @Override
    public String getName() {
        return "Customer";
    }

    @Override
    public String getId(Object object) {
        return ((Customer) object).getId().toString();
    }
}
