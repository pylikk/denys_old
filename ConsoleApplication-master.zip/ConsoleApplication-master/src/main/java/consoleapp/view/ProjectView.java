package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.TeamController;
import consoleapp.dao.TeamDAO;
import consoleapp.model.Project;
import consoleapp.model.Team;

import java.util.List;

public class ProjectView extends AbstractView {

    private TeamController teamController = new TeamController(new TeamDAO());
    private TeamView teamView = new TeamView(teamController);

    public ProjectView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Project!");
            return false;
        }
        else {
            for (Object o : list) {
                Project project = (Project) o;
                System.out.println(project.getId() + " " + project.getName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Project project = new Project();
        System.out.println("Enter the Project's name:");
        project.setName(readString());

        if (teamView.all()) {
            System.out.println("Select some Project's teams - enter numbers, separeted by commas");
            List<Integer> teams;
            if ((teams = readSet(teamController)) == null) {
                controller.add(project);
            }
            else {
                project.setTeams(teams);
            }
        }
        controller.add(project);
        System.out.println("Project succesfully added!");
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Project project = (Project) controller.getObject(Integer.parseInt(id));
            System.out.println("Project's id: \"" + project.getId()+"\"");
            System.out.println("Project's name: \"" + project.getName()+"\"");

            List<Integer> teams = project.getTeams();
            if (teams.isEmpty())
                System.out.println("Project's TEAM: no TEAMS");
            else {
                String str = "";
                for (Integer i : teams) {
                    if (i != null) {
                        Team team = (Team) teamController.getObject(i);
                        if (team != null)
                            str += team.getName();
                    }
                }
                System.out.println("Project's TEAMS: " + str);
            }
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            int i = Integer.parseInt(id);
            Project project = (Project) controller.getObject(i);
            System.out.println("Enter the Project's name:");
            String name = readString();
            if (!name.equals(""))
                project.setName(name);

            if (teamView.all()) {
                System.out.println("Select some Project's Teams - enter numbers, separeted by commas");
                List<Integer> teams;
                if ((teams = readSet(new TeamController(new TeamDAO()))) == null) {
                    controller.update(project);
                }
                else {
                    project.setTeams(teams);
                }
            }
            controller.update(project);
            System.out.println("Project succesfully updated!");
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> PROJECT ");
    }
}
