package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.SkillController;
import consoleapp.dao.SkillDAO;
import consoleapp.model.Developer;
import consoleapp.model.Skill;

import java.util.List;

public class DeveloperView extends AbstractView{

    private SkillController skillController = new SkillController(new SkillDAO());
    private SkillView skillView = new SkillView(skillController);

    public DeveloperView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Developer!");
            return false;
        }
        else {
            for (Object o : list) {
                Developer developer = (Developer) o;
                System.out.println(developer.getId() + " " + developer.getFirstName() + " " + developer.getLastName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Developer developer = new Developer();
        System.out.println("Enter the Developer's Firstname:");
        developer.setFirstName(readString());
        System.out.println("Enter the Developer's Lastname:");
        developer.setLastName(readString());
        System.out.println("Enter the Developer's age:");
        developer.setAge(Integer.parseInt(readInt()));
        if (skillView.all()) {
            System.out.println("Select some Developer's Skills - enter numbers, separeted by commas");
            List<Integer> skills;
            if ((skills = readSet(skillController)) == null) {
                controller.add(developer);
            }
            else {
                developer.setSkills(skills);
            }
        }
        controller.add(developer);
        System.out.println("Developer succesfully added!");
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Developer developer = (Developer) controller.getObject(Integer.parseInt(id));
            System.out.println("Developer's id: \"" + developer.getId()+"\"");
            System.out.println("Developer's Firstname: \"" + developer.getFirstName()+"\"");
            System.out.println("Developer's Lastname: \"" + developer.getLastName()+"\"");
            System.out.println("Developer's age: \"" + developer.getAge()+"\"");

            List<Integer> skills = developer.getSkills();
            if (skills.isEmpty())
                System.out.println("\"Developer's SKILLS: no skills");
            else {
                String str = "";
                for (Integer i : skills) {
                    if (i != null) {
                        Skill skill = (Skill) skillController.getObject(i);
                        if (skill != null)
                            str += skill.getName() + " ";
                    }
                }
                System.out.println("Developer's SKILLS: " + str);
            }
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            int i = Integer.parseInt(id);
            Developer developer = (Developer) controller.getObject(i);
            System.out.println("Enter the Developer's Firstname:");
            String firstName = readString();
            if (!firstName.equals(""))
                developer.setFirstName(firstName);
            System.out.println("Enter the Developer's Lastname:");
            String lastName = readString();
            if (!lastName.equals(""))
                developer.setLastName(lastName);
            System.out.println("Enter the Developer's age:");
            String age = readString();
            if (!age.equals(""))
                developer.setAge(Integer.parseInt(age));
            if (skillView.all()) {
                System.out.println("Select some Developer's Skills - enter numbers, separeted by commas");
                List<Integer> skills;
                if ((skills = readSet(new SkillController(new SkillDAO()))) == null) {
                    controller.update(developer);
                }
                else {
                    developer.setSkills(skills);
                }
            }
            controller.update(developer);
            System.out.println("Developer succesfully updated!");
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> DEVELOPER ");
    }
}
