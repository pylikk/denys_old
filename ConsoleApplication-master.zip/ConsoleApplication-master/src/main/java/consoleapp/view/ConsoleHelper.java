package consoleapp.view;

import consoleapp.controller.*;
import consoleapp.dao.*;

public class ConsoleHelper {

    private final String line = "------------------------------------------------------";

    ControllerHelper controllerHelper = ControllerHelper.getControllerHelper();
    AbstractView view;

    public void start() {
        System.out.println("WELCOME!");
        System.out.println(line);
        chooseEntity();
    }

    /* MAIN MENU */
    public void chooseEntity () {
        while (true) {
            showEntities();
            System.out.println("Enter the name of one of the entities above:");
            String entity = controllerHelper.readConsole();
            if (entity.equalsIgnoreCase("SKILL")) {
                view = new SkillView(new SkillController(new SkillDAO()));
                view.chooseCommand();
            }
            else if (entity.equalsIgnoreCase("DEVELOPER")) {
                view = new DeveloperView(new DeveloperController(new DeveloperDAO()));
                view.chooseCommand();
            }
            else if (entity.equalsIgnoreCase("TEAM")) {
                view = new TeamView(new TeamController(new TeamDAO()));
                view.chooseCommand();
            }
            else if (entity.equalsIgnoreCase("PROJECT")) {
                view = new ProjectView(new ProjectController(new ProjectDAO()));
                view.chooseCommand();
            }
            else if (entity.equalsIgnoreCase("CUSTOMER")) {
                view = new CustomerView(new CustomerController(new CustomerDAO()));
                view.chooseCommand();
            }
            else if (entity.equalsIgnoreCase("COMPANY")) {
                view = new CompanyView(new CompanyController(new CompanyDAO()));
                view.chooseCommand();
            }
            else
                System.out.println("No entity with this name. Try again");

        }
    }

    private void showEntities () {
        System.out.println("Company");
        System.out.println("Customer");
        System.out.println("Project");
        System.out.println("Team");
        System.out.println("Developer");
        System.out.println("Skill");
        System.out.println(line);
    }
}
