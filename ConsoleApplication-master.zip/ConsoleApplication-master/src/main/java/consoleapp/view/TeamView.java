package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.DeveloperController;
import consoleapp.dao.DeveloperDAO;
import consoleapp.model.Developer;
import consoleapp.model.Team;
import java.util.List;

public class TeamView extends AbstractView {

    private DeveloperController developerController = new DeveloperController(new DeveloperDAO());
    private DeveloperView developerView = new DeveloperView(developerController);

    public TeamView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Team!");
            return false;
        }
        else {
            for (Object o : list) {
                Team team = (Team) o;
                System.out.println(team.getId() + " " + team.getName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Team team = new Team();
        System.out.println("Enter the Team's name:");
        team.setName(readString());

        if (developerView.all()) {
            System.out.println("Select some Team's Developers - enter numbers, separeted by commas");
            List<Integer> developers;
            if ((developers = readSet(developerController)) == null) {
                controller.add(team);
            }
            else {
                team.setDevelopers(developers);
            }
        }
        controller.add(team);
        System.out.println("Team succesfully added!");
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Team team = (Team) controller.getObject(Integer.parseInt(id));
            System.out.println("Team's id: \"" + team.getId()+"\"");
            System.out.println("Team's name: \"" + team.getName()+"\"");

            List<Integer> developers = team.getDevelopers();
            if (developers.isEmpty())
                System.out.println("Team's DEVELOPERS: no developers");
            else {
                String str = "";
                for (Integer i : developers) {
                    if (i != null) {
                        Developer developer = (Developer) developerController.getObject(i);
                        if (developer != null)
                            str += developer.getFirstName() + " " + developer.getLastName();
                    }
                }
                System.out.println("Team's DEVELOPERS: " + str);
            }
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            int i = Integer.parseInt(id);
            Team team = (Team) controller.getObject(i);
            System.out.println("Enter the Team's name:");
            String name = readString();
            if (!name.equals(""))
                team.setName(name);

            if (developerView.all()) {
                System.out.println("Select some Team's Developers - enter numbers, separeted by commas");
                List<Integer> developers;
                if ((developers = readSet(new DeveloperController(new DeveloperDAO()))) == null) {
                    controller.update(team);
                }
                else {
                    team.setDevelopers(developers);
                }
            }
            controller.update(team);
            System.out.println("Team succesfully updated!");
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> TEAM ");
    }
}
