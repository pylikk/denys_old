package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.model.Skill;

import java.util.List;

public class SkillView extends AbstractView {

    public SkillView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Skill!");
            return false;
        }
        else {
            for (Object o : list) {
                Skill skill = (Skill) o;
                System.out.println(skill.getId() + " " + skill.getName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Skill skill = new Skill();
        System.out.println("Enter the Skill's name:");
        skill.setName(readString());
        controller.add(skill);
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Skill skill = (Skill) controller.getObject(Integer.parseInt(id));
            System.out.println("Skill id: \"" + skill.getId()+"\"");
            System.out.println("Skill name: \"" + skill.getName()+"\"");
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            Skill skill = (Skill) controller.getObject(Integer.parseInt(id));
            System.out.println("Enter the Skill's name:");
            String name = readString();
            if (!name.equals(""))
                skill.setName(name);

            controller.update(skill);
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> SKILL ");
    }
}
