package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.ProjectController;
import consoleapp.dao.ProjectDAO;
import consoleapp.model.Customer;
import consoleapp.model.Project;

import java.util.List;

public class CustomerView extends AbstractView {

    private ProjectController projectController = new ProjectController(new ProjectDAO());
    private ProjectView projectView = new ProjectView(projectController);

    public CustomerView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Customer!");
            return false;
        }
        else {
            for (Object o : list) {
                Customer customer = (Customer) o;
                System.out.println(customer.getId() + " " + customer.getName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Customer customer = new Customer();
        System.out.println("Enter the Customer's name:");
        customer.setName(readString());

        if (projectView.all()) {
            System.out.println("Select some Customer's projects - enter numbers, separeted by commas");
            List<Integer> projects;
            if ((projects = readSet(projectController)) == null) {
                controller.add(customer);
            }
            else {
                customer.setProjects(projects);
            }
        }
        controller.add(customer);
        System.out.println("Customer succesfully added!");
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Customer customer = (Customer) controller.getObject(Integer.parseInt(id));
            System.out.println("Customer's id: \"" + customer.getId()+"\"");
            System.out.println("Customer's name: \"" + customer.getName()+"\"");

            List<Integer> projects = customer.getProjects();
            if (projects.isEmpty())
                System.out.println("Customer's PROJECTS: no projects");
            else {
                String str = "";
                for (Integer i : projects) {
                    if (i != null) {
                        Project project = (Project) projectController.getObject(i);
                        if (project != null)
                            str += project.getName();
                    }
                }
                System.out.println("Customer's PROJECTS: " + str);
            }
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            int i = Integer.parseInt(id);
            Customer customer = (Customer) controller.getObject(i);
            System.out.println("Enter the Customer's name:");
            String name = readString();
            if (!name.equals(""))
                customer.setName(name);

            if (projectView.all()) {
                System.out.println("Select some Customer's Projects - enter numbers, separeted by commas");
                List<Integer> projects;
                if ((projects = readSet(new ProjectController(new ProjectDAO()))) == null) {
                    controller.update(customer);
                }
                else {
                    customer.setProjects(projects);
                }
            }
            controller.update(customer);
            System.out.println("Customer succesfully updated!");
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> CUSTOMER ");
    }
}
