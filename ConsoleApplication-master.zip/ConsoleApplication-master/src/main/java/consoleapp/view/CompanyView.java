package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.CustomerController;
import consoleapp.dao.CustomerDAO;
import consoleapp.model.Company;
import consoleapp.model.Customer;

import java.util.List;

public class CompanyView extends AbstractView {


    private CustomerController customerController = new CustomerController(new CustomerDAO());
    private CustomerView customerView = new CustomerView(customerController);

    public CompanyView(AbstractController controller) {
        super(controller);
    }

    @Override
    public boolean all() {
        List<Object> list = controller.all();
        if (list.isEmpty()) {
            System.out.println("Emphty! Add new Company!");
            return false;
        }
        else {
            for (Object o : list) {
                Company company = (Company) o;
                System.out.println(company.getId() + " " + company.getName());
            }
            System.out.println(line);
            return true;
        }
    }

    @Override
    public void add() {
        Company company = new Company();
        System.out.println("Enter the Company's name:");
        company.setName(readString());

        if (customerView.all()) {
            System.out.println("Select some Company's customers - enter numbers, separeted by commas");
            List<Integer> customers;
            if ((customers = readSet(customerController)) == null) {
                controller.add(company);
            }
            else {
                company.setCustomers(customers);
            }
        }
        controller.add(company);
        System.out.println("Company succesfully added!");
    }

    @Override
    public void show() {
        String id = readId();
        if (id != null) {
            Company company = (Company) controller.getObject(Integer.parseInt(id));
            System.out.println("Company's id: \"" + company.getId()+"\"");
            System.out.println("Company's name: \"" + company.getName()+"\"");

            List<Integer> customers = company.getCustomers();
            if (customers.isEmpty())
                System.out.println("Company's CUSTOMERS: no customers");
            else {
                String str = "";
                for (Integer i : customers) {
                    if (i != null) {
                        Customer customer = (Customer) customerController.getObject(i);
                        if (customer != null)
                            str += customer.getName();
                    }
                }
                System.out.println("Company's CUSTOMERS: " + str);
            }
        }
    }

    @Override
    public void update() {
        String id = readId();
        if (id != null) {
            int i = Integer.parseInt(id);
            Company company = (Company) controller.getObject(i);
            System.out.println("Enter the Company's name:");
            String name = readString();
            if (!name.equals(""))
                company.setName(name);

            if (customerView.all()) {
                System.out.println("Select some Company's Customers - enter numbers, separeted by commas");
                List<Integer> customers;
                if ((customers = readSet(new CustomerController(new CustomerDAO()))) == null) {
                    controller.update(company);
                }
                else {
                    company.setCustomers(customers);
                }
            }
            controller.update(company);
            System.out.println("Company succesfully updated!");
        }
    }

    @Override
    public void showEntityName() {
        System.out.println(">>> MENU >>> COMPANY ");
    }
}
