package consoleapp.view;

import consoleapp.controller.AbstractController;
import consoleapp.controller.ControllerHelper;
import consoleapp.controller.SkillController;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractView {

    protected final String line = "------------------------------------------------------";

    AbstractController controller;
    ControllerHelper controllerHelper = ControllerHelper.getControllerHelper();

    public abstract boolean all();
    public abstract void add();
    public abstract void show();
    public abstract void update();
    public abstract void showEntityName();

    public AbstractView(AbstractController controller) {
        this.controller = controller;
    }

    public void delete() {
        String id = readId();
        if (id != null) {
            controller.delete(id);
        }
    }

    public void chooseCommand () {
        while (true) {
            showChoose();
            String command = controllerHelper.readConsole();
            if (command == null)
                break;
            else if (command.equalsIgnoreCase("ALL"))
                all();
            else if (command.equalsIgnoreCase("ADD"))
                add();
            else if (command.equalsIgnoreCase("SHOW"))
                show();
            else if (command.equalsIgnoreCase("UPDATE"))
                update();
            else if (command.equalsIgnoreCase("DELETE"))
                delete();
            else
                System.out.println("Incorrect command! ");
        }
    }

    private void showChoose() {
        showEntityName();
        System.out.println("Commands: ALL, ADD, SHOW, UPDATE, DELETE  /  MENU, EXIT");
    }

    public String readString () {
        String data = controller.readConsole();
        if (data == null)
            return null;
        else
            return data;
    }

    public String readId () {
        System.out.println("Enter ID:");
        while (true) {
            String data = controller.readConsole();
            if (data == null)
                return null;
            try {
                int id = Integer.parseInt(data);
                if (controller.getObject(id) != null)
                    return data;
                System.out.println("Incorrect id!");
            } catch (Exception e) {
                System.out.println("Enter a correct number!");
            }
        }
    }

    public String readInt () {
        while (true) {
            String data = controller.readConsole();
            try {
                Integer.parseInt(data);
                return data;
            } catch (Exception e) {
                System.out.println("Enter a correct number!");
            }
        }
    }

    public List<Integer> readSet (AbstractController controller) {
        List<Integer> list = new ArrayList<>();
        while (true) {
            String str = controller.readConsole();
            if (str == null)
                return null;
            if (str.equals(""))
                return list;
            str += ",";
            do {
                str = str.trim();
                String number;
                if (str.contains(",")) {
                    number = str.substring(0, str.indexOf(","));
                } else {
                    number = str;
                }
                try {
                    Integer id = Integer.parseInt(number);
                    if (controller.getObject(id) == null) {
                        System.out.println("Not all entities exist or syntax error. Check the entered numbers and syntax");
                        return null;
                    }
                    list.add(id);
                } catch (Exception e) {
                    System.out.println("Not all entities exist or syntax error. Check the entered numbers and syntax");
                    return null;
                }
                str = str.substring(str.indexOf(",") + 1);
            } while (str.contains(","));
            return list;

        }
    }

}
